package Principal;

import Metodos.LectorTeclado;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Intro un numero entre 1 y 4");
		LectorTeclado.leerInt(1, 4);
	}

}
